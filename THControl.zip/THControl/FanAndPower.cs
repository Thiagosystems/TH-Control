using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LibreHardwareMonitor.Hardware;

namespace THControl
{
    /// <summary>Uma saída de ventoinha que pode ser controlada pelo software.</summary>
    public class FanChannel : Observable
    {
        int _mode, _manual = 50;
        string _status = "";

        public string Id { get; init; } = "";
        public string Name { get; init; } = "";
        public bool IsGpu { get; init; }
        public ISensor Sensor { get; init; } = null!;

        /// <summary>0 = segue o perfil, 1 = manual, 2 = automático (BIOS/driver)</summary>
        public int Mode { get => _mode; set { if (Set(ref _mode, value)) { Raise(nameof(IsManual)); Raise(nameof(ModeProfile)); Raise(nameof(ModeManual)); Raise(nameof(ModeAuto)); } } }
        public int Manual { get => _manual; set { if (Set(ref _manual, value)) Raise(nameof(ManualText)); } }
        public bool IsManual => Mode == 1;
        public string ManualText => $"{Manual}%";
        public string Status { get => _status; set => Set(ref _status, value); }
        public bool ModeProfile { get => Mode == 0; set { if (value) Mode = 0; } }
        public bool ModeManual { get => Mode == 1; set { if (value) Mode = 1; } }
        public bool ModeAuto { get => Mode == 2; set { if (value) Mode = 2; } }
    }

    public record PowerProfile(string Id, string Name, string Description, string Scheme, int MaxCpu, int Cooling, int FanMin, int FanMax);

    public static class FanAndPower
    {
        public static readonly PowerProfile[] Profiles =
        {
            new("silent", "Silencioso", "CPU limitada a 70%, resfriamento passivo e ventoinhas baixas", "SCHEME_BALANCED", 70, 0, 20, 60),
            new("balanced", "Equilibrado", "Padrão do Windows com ventoinhas moderadas", "SCHEME_BALANCED", 100, 1, 30, 85),
            new("performance", "Desempenho", "Alto desempenho e ventoinhas fortes", "SCHEME_MIN", 100, 1, 50, 100),
        };

        public const float CurveLow = 40, CurveHigh = 80, Emergency = 90;

        // ------------------------------------------------------------ energia

        public static async Task ApplyPowerAsync(PowerProfile p)
        {
            string scheme = p.Scheme;
            if (p.Id == "performance")
            {
                // Usa "Desempenho máximo" se existir neste PC
                var (_, list) = await Shell.RunAsync("powercfg.exe", "/list");
                var ultimate = Regex.Match(list, @"([0-9a-fA-F\-]{36})\s+\((Desempenho Máximo|Ultimate Performance)\)", RegexOptions.IgnoreCase);
                if (ultimate.Success) scheme = ultimate.Groups[1].Value;
            }
            await Shell.RunAsync("powercfg.exe", $"/setactive {scheme}");
            foreach (var mode in new[] { "/setacvalueindex", "/setdcvalueindex" })
            {
                await Shell.RunAsync("powercfg.exe", $"{mode} SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX {p.MaxCpu}");
                await Shell.RunAsync("powercfg.exe", $"{mode} SCHEME_CURRENT SUB_PROCESSOR SYSCOOLPOL {p.Cooling}");
            }
            await Shell.RunAsync("powercfg.exe", "/setactive SCHEME_CURRENT");
        }

        public static async Task<string> ActivePlanNameAsync()
        {
            var (_, o) = await Shell.RunAsync("powercfg.exe", "/getactivescheme");
            var m = Regex.Match(o, @"\(([^)]+)\)\s*$");
            return m.Success ? m.Groups[1].Value : "";
        }

        // --------------------------------------------------------- ventoinhas

        public static List<FanChannel> FindChannels(HardwareService hw, Settings s) => hw.Read(() =>
        {
            var list = new List<FanChannel>();
            foreach (var (h, group, sensor) in hw.All())
            {
                if (sensor.SensorType != SensorType.Control || sensor.Control == null) continue;
                string id = sensor.Identifier.ToString();
                var saved = s.Fans.TryGetValue(id, out var f) ? f : new FanSetting();
                list.Add(new FanChannel
                {
                    Id = id,
                    Name = $"{sensor.Name} — {group}",
                    IsGpu = h.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel,
                    Sensor = sensor,
                    Mode = saved.Mode,
                    Manual = saved.Manual
                });
            }
            return list;
        });

        /// <summary>Curva: abaixo de 40 °C usa o mínimo, acima de 80 °C o máximo; 90 °C ou mais = 100%.</summary>
        public static float CurveValue(PowerProfile p, float? temp)
        {
            if (temp is not float t) return p.FanMax;
            if (t >= Emergency) return 100;
            float k = Math.Clamp((t - CurveLow) / (CurveHigh - CurveLow), 0, 1);
            return p.FanMin + (p.FanMax - p.FanMin) * k;
        }

        /// <summary>Aplica o modo de cada ventoinha. Chamar a cada atualização.</summary>
        public static void ApplyFans(HardwareService hw, IEnumerable<FanChannel> channels, string profileId, float? cpuTemp, float? gpuTemp)
        {
            var profile = Profiles.FirstOrDefault(p => p.Id == profileId);
            hw.Do(() =>
            {
                foreach (var ch in channels)
                {
                    var ctrl = ch.Sensor.Control;
                    if (ctrl == null) continue;
                    try
                    {
                        float? temp = ch.IsGpu ? gpuTemp : cpuTemp;
                        if (ch.Mode == 2 || (ch.Mode == 0 && profile == null))
                        {
                            if (ctrl.ControlMode != ControlMode.Default) ctrl.SetDefault();
                            ch.Status = "Automático";
                        }
                        else
                        {
                            float target = ch.Mode == 1 ? ch.Manual : CurveValue(profile!, temp);
                            if (temp is float t && t >= Emergency) target = 100; // segurança
                            target = Math.Clamp(target, ctrl.MinSoftwareValue, ctrl.MaxSoftwareValue);
                            ctrl.SetSoftware(target);
                            ch.Status = $"{target:0}%";
                        }
                    }
                    catch { ch.Status = "Sem controle"; }
                }
            });
        }

        public static void RestoreFans(HardwareService hw, IEnumerable<FanChannel> channels) => hw.Do(() =>
        {
            foreach (var ch in channels)
            {
                try { ch.Sensor.Control?.SetDefault(); } catch { }
            }
        });
    }
}

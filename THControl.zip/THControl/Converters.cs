using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace THControl
{
    /// <summary>Visível quando o valor é "verdadeiro": true, texto não vazio, número &gt; 0, objeto não nulo.</summary>
    public class VisibleIf : IValueConverter
    {
        public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            bool show = value switch
            {
                null => false,
                bool b => b,
                string s => s.Length > 0,
                int i => i > 0,
                long l => l > 0,
                _ => true
            };
            if (parameter is string p && p == "invert") show = !show;
            return show ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
            throw new NotSupportedException();
    }
}

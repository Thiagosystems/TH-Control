using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using WF = System.Windows.Forms;

namespace THControl
{
    public class DiskView : Observable
    {
        string _temp = "—", _health = "—", _written = "—", _used = "—";
        double _healthValue;
        public string Name { get; init; } = "";
        public string TempText { get => _temp; set => Set(ref _temp, value); }
        public string HealthText { get => _health; set => Set(ref _health, value); }
        public double HealthValue { get => _healthValue; set => Set(ref _healthValue, value); }
        public string WrittenText { get => _written; set => Set(ref _written, value); }
        public string UsedText { get => _used; set => Set(ref _used, value); }
    }

    public class FanView : Observable
    {
        float _rpm;
        public string Name { get; init; } = "";
        public float Rpm { get => _rpm; set => Set(ref _rpm, value); }
    }

    public partial class MainWindow : Window
    {
        const int GraphSamples = 120, PingSamples = 60;

        readonly Settings _s;
        readonly HardwareService _hw = new();
        readonly DispatcherTimer _timer = new();
        readonly DispatcherTimer _pingTimer = new() { Interval = TimeSpan.FromSeconds(1) };
        readonly ObservableCollection<SensorRow> _rows = new();
        readonly Dictionary<string, SensorRow> _rowById = new();
        readonly ObservableCollection<DiskView> _disks = new();
        readonly ObservableCollection<FanView> _fans = new();
        readonly List<DnsProvider> _dns = NetworkTools.Providers();
        readonly Queue<float?> _cpuTemps = new(), _gpuTemps = new();
        readonly List<long?> _pings = new();
        readonly ICollectionView _sensorView;
        readonly bool _startHidden;

        List<FanChannel> _channels = new();
        WF.NotifyIcon _tray = null!;
        HwSummary _last = new();
        AdapterInfo? _adapter;
        long _lastRx = -1, _lastTx = -1;
        DateTime _lastNetSample = DateTime.Now;
        bool _busy, _loading = true, _exiting, _pinging;

        public MainWindow(Settings settings, bool startHidden)
        {
            InitializeComponent();
            _s = settings;
            _startHidden = startHidden;
            Icon = System.Windows.Media.Imaging.BitmapFrame.Create(new Uri("pack://application:,,,/Assets/app.ico"));

            string version = typeof(MainWindow).Assembly.GetName().Version?.ToString(3) ?? "1.0.0";
            TxtVersion.Text = "v" + version;
            TxtAbout.Text = $"Versão {version} · Monitor de hardware, perfis de ventoinha e energia, e otimizador de internet para jogos.";

            _sensorView = CollectionViewSource.GetDefaultView(_rows);
            _sensorView.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SensorRow.Group)));
            _sensorView.Filter = o => o is SensorRow r && MatchSensor(r);
            LstSensors.ItemsSource = _sensorView;
            ListDisks.ItemsSource = _disks;
            ListFans.ItemsSource = _fans;
            ListDns.ItemsSource = _dns;

            SetupTray();
            BuildSwatches();
            LoadSettingsUi();
            HookSettings();
            SelectProfileCard(_s.Profile);
            UpdatePawnUi();
            RefreshNetworkInfo();

            StateChanged += (_, _) =>
            {
                Root.Margin = WindowState == WindowState.Maximized ? new Thickness(7) : new Thickness(0);
                BtnMax.Content = WindowState == WindowState.Maximized ? "" : "";
            };

            _timer.Tick += async (_, _) => await TickAsync();
            _pingTimer.Tick += async (_, _) => await PingAsync();
            Loaded += async (_, _) => await StartAsync();
            _loading = false;
        }

        void Status(string text) => TxtStatus.Text = text;
        void ShowBusy(string text) { TxtBusy.Text = text; BusyOverlay.Visibility = Visibility.Visible; }
        void HideBusy() => BusyOverlay.Visibility = Visibility.Collapsed;
        bool Confirm(string text) => MessageBox.Show(this, text, "TH Control", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;

        // =====================================================================
        //  Início
        // =====================================================================

        async Task StartAsync()
        {
            if (_startHidden) Hide();
            Status("Abrindo sensores...");
            await Task.Run(() => { _hw.Open(); _hw.Update(); });

            if (!_hw.IsOpen)
            {
                TxtDashSub.Text = "Não foi possível abrir os sensores: " + _hw.Error;
                Status("Erro ao abrir os sensores.");
                return;
            }

            // Lista de sensores (estrutura fixa; valores são atualizados a cada ciclo)
            var rows = _hw.Read(() => _hw.All().Select(x => new SensorRow
            {
                Id = x.Sensor.Identifier.ToString(),
                Group = x.Group,
                Name = x.Sensor.Name,
                Type = x.Sensor.SensorType
            }).ToList());
            foreach (var r in rows)
            {
                if (_rowById.ContainsKey(r.Id)) continue;
                _rowById[r.Id] = r;
                _rows.Add(r);
            }
            TxtSensorCount.Text = $"{_rows.Count} sensores em {_rows.Select(r => r.Group).Distinct().Count()} dispositivos";

            _channels = FanAndPower.FindChannels(_hw, _s);
            foreach (var ch in _channels) ch.PropertyChanged += Channel_PropertyChanged;
            ListChannels.ItemsSource = _channels;
            TxtNoControl.Visibility = _channels.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

            if (_s.Profile != "none")
            {
                var p = FanAndPower.Profiles.FirstOrDefault(x => x.Id == _s.Profile);
                if (p != null) await FanAndPower.ApplyPowerAsync(p);
            }
            await RefreshPlanAsync();

            _timer.Interval = TimeSpan.FromMilliseconds(Math.Clamp(_s.RefreshMs, 1000, 5000));
            _timer.Start();
            await TickAsync();
            Status("Pronto.");
        }

        // =====================================================================
        //  Ciclo de atualização
        // =====================================================================

        async Task TickAsync()
        {
            if (_busy || !_hw.IsOpen) return;
            _busy = true;
            bool f = _s.Fahrenheit;
            bool needRows = IsVisible && PageSensors.Visibility == Visibility.Visible;
            string profile = _s.Profile;
            HwSummary sum = new();
            List<(string Id, string V, string Min, string Max)>? values = null;

            try
            {
                await Task.Run(() =>
                {
                    _hw.Update();
                    sum = _hw.Summary();
                    if (_channels.Count > 0)
                        FanAndPower.ApplyFans(_hw, _channels, profile, sum.CpuTemp, sum.GpuTemp);
                    if (needRows)
                        values = _hw.Read(() => _hw.All().Select(x => (
                            x.Sensor.Identifier.ToString(),
                            HardwareService.Format(x.Sensor.SensorType, x.Sensor.Value, f),
                            HardwareService.Format(x.Sensor.SensorType, x.Sensor.Min, f),
                            HardwareService.Format(x.Sensor.SensorType, x.Sensor.Max, f))).ToList());
                });
            }
            catch (Exception ex) { Status("Erro ao ler sensores: " + ex.Message); }

            _last = sum;
            if (values != null)
                foreach (var v in values)
                    if (_rowById.TryGetValue(v.Id, out var row)) { row.Value = v.V; row.Min = v.Min; row.Max = v.Max; }

            UpdateDashboard(sum);
            UpdateNetworkSpeed();
            _busy = false;
        }

        void UpdateDashboard(HwSummary s)
        {
            bool f = _s.Fahrenheit;
            string T(float? v) => HardwareService.Temp(v, f);

            TxtDashSub.Text = string.Join("  ·  ", new[] { s.CpuName, s.GpuName }.Where(x => x.Length > 0));

            TxtCpuName.Text = s.CpuName;
            TxtCpuTemp.Text = T(s.CpuTemp);
            TxtCpuLoad.Text = s.CpuLoad is float cl ? $"{cl:0}%" : "—";
            TxtCpuLoadPct.Text = TxtCpuLoad.Text;
            TxtCpuClock.Text = s.CpuClock is float cc ? $"{cc / 1000:0.00} GHz" : "—";
            TxtCpuPower.Text = s.CpuPower is float cp ? $"{cp:0} W" : "—";
            PrgCpu.Value = s.CpuLoad ?? 0;

            TxtGpuName.Text = s.GpuName;
            TxtGpuTemp.Text = T(s.GpuTemp);
            TxtGpuHot.Text = s.GpuHotspot.HasValue ? "Hot spot " + T(s.GpuHotspot) : "";
            TxtGpuLoad.Text = s.GpuLoad is float gl ? $"{gl:0}%" : "—";
            TxtGpuClock.Text = s.GpuClock is float gc ? $"{gc:0} MHz" : "—";
            TxtGpuPower.Text = s.GpuPower is float gp ? $"{gp:0} W" : "—";
            TxtGpuMem.Text = s.GpuMemUsed is float mu
                ? (s.GpuMemTotal is float mt && mt > 0 ? $"{mu / 1024:0.0}/{mt / 1024:0} GB" : $"{mu / 1024:0.0} GB")
                : "—";
            PrgGpu.Value = s.GpuLoad ?? 0;

            if (s.RamUsed is float ru && s.RamAvail is float ra)
            {
                TxtRamPct.Text = $"{s.RamLoad ?? ru / (ru + ra) * 100:0}%";
                TxtRamUsed.Text = $"{ru:0.0} GB";
                TxtRamFree.Text = $"{ra:0.0} GB";
                TxtRamDetail.Text = $"{ru + ra:0} GB no total";
                PrgRam.Value = s.RamLoad ?? ru / (ru + ra) * 100;
            }

            // Discos
            for (int i = 0; i < s.Disks.Count; i++)
            {
                var d = s.Disks[i];
                if (i >= _disks.Count || _disks[i].Name != d.Name)
                {
                    while (_disks.Count > i) _disks.RemoveAt(_disks.Count - 1);
                    _disks.Add(new DiskView { Name = d.Name });
                }
                var v = _disks[i];
                v.TempText = T(d.Temp);
                v.HealthText = d.Health is float h ? $"{h:0}%" : "sem dados";
                v.HealthValue = d.Health ?? 0;
                v.WrittenText = d.WrittenGB is float w ? (w >= 1024 ? $"{w / 1024:0.0} TB" : $"{w:0} GB") : "—";
                v.UsedText = d.UsedPct is float u ? $"{u:0}%" : "—";
            }
            while (_disks.Count > s.Disks.Count) _disks.RemoveAt(_disks.Count - 1);
            TxtNoDisks.Visibility = _disks.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

            // Ventoinhas
            for (int i = 0; i < s.Fans.Count; i++)
            {
                var fan = s.Fans[i];
                if (i >= _fans.Count || _fans[i].Name != fan.Name)
                {
                    while (_fans.Count > i) _fans.RemoveAt(_fans.Count - 1);
                    _fans.Add(new FanView { Name = fan.Name });
                }
                _fans[i].Rpm = fan.Rpm;
            }
            while (_fans.Count > s.Fans.Count) _fans.RemoveAt(_fans.Count - 1);
            TxtNoFans.Visibility = _fans.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

            // Gráfico
            _cpuTemps.Enqueue(s.CpuTemp);
            _gpuTemps.Enqueue(s.GpuTemp);
            while (_cpuTemps.Count > GraphSamples) _cpuTemps.Dequeue();
            while (_gpuTemps.Count > GraphSamples) _gpuTemps.Dequeue();
            if (IsVisible && PageDash.Visibility == Visibility.Visible)
            {
                GraphCpu.Data = Line(_cpuTemps.ToList(), TempGraph.ActualWidth, TempGraph.ActualHeight, GraphSamples, 100);
                GraphGpu.Data = Line(_gpuTemps.ToList(), TempGraph.ActualWidth, TempGraph.ActualHeight, GraphSamples, 100);
            }

            string side = $"CPU {T(s.CpuTemp)}  ·  GPU {T(s.GpuTemp)}";
            TxtSideTemps.Text = side;
            string tip = $"TH Control — {side}";
            _tray.Text = tip.Length > 63 ? tip[..63] : tip;
        }

        /// <summary>Linha de um gráfico; valores nulos quebram a linha.</summary>
        static Geometry? Line(IList<float?> values, double w, double h, int capacity, double max)
        {
            if (w <= 0 || h <= 0 || values.Count < 2) return null;
            double step = w / (capacity - 1);
            double x0 = w - (values.Count - 1) * step;
            var g = new StreamGeometry();
            using (var c = g.Open())
            {
                bool open = false;
                for (int i = 0; i < values.Count; i++)
                {
                    if (values[i] is not float v) { open = false; continue; }
                    var pt = new Point(x0 + i * step, h - 4 - (h - 8) * Math.Clamp(v / max, 0, 1));
                    if (!open) { c.BeginFigure(pt, false, false); open = true; }
                    else c.LineTo(pt, true, true);
                }
            }
            g.Freeze();
            return g;
        }

        // =====================================================================
        //  Navegação e janela
        // =====================================================================

        void Nav_Checked(object sender, RoutedEventArgs e)
        {
            if (PageDash == null) return;
            PageDash.Visibility = sender == NavDash ? Visibility.Visible : Visibility.Collapsed;
            PageSensors.Visibility = sender == NavSensors ? Visibility.Visible : Visibility.Collapsed;
            PageFans.Visibility = sender == NavFans ? Visibility.Visible : Visibility.Collapsed;
            PageNet.Visibility = sender == NavNet ? Visibility.Visible : Visibility.Collapsed;
            PageSettings.Visibility = sender == NavSettings ? Visibility.Visible : Visibility.Collapsed;

            if (sender == NavNet) { RefreshNetworkInfo(); RefreshNetTweaks(); }
            if (sender == NavFans) _ = RefreshPlanAsync();
            if (sender == NavSensors) _ = TickAsync();
        }

        void Min_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        void Max_Click(object sender, RoutedEventArgs e) =>
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

        void Close_Click(object sender, RoutedEventArgs e)
        {
            if (_s.CloseToTray) HideToTray();
            else ExitApp();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            if (!_exiting)
            {
                e.Cancel = true;
                if (_s.CloseToTray) HideToTray(); else ExitApp();
            }
            base.OnClosing(e);
        }

        void HideToTray()
        {
            Hide();
            if (!_s.TrayHintShown)
            {
                _s.TrayHintShown = true;
                _s.Save();
                _tray.ShowBalloonTip(3000, "TH Control", "Continua rodando na bandeja para manter o perfil das ventoinhas.", WF.ToolTipIcon.Info);
            }
        }

        void ShowFromTray()
        {
            Show();
            WindowState = WindowState.Normal;
            Activate();
        }

        void ExitApp()
        {
            _exiting = true;
            _timer.Stop();
            _pingTimer.Stop();
            if (_s.RestoreFansOnExit && _channels.Count > 0) FanAndPower.RestoreFans(_hw, _channels);
            _hw.Dispose();
            _s.Save();
            _tray.Visible = false;
            _tray.Dispose();
            Application.Current.Shutdown();
        }

        void SetupTray()
        {
            var menu = new WF.ContextMenuStrip();
            menu.Items.Add("Abrir", null, (_, _) => ShowFromTray());
            menu.Items.Add(new WF.ToolStripSeparator());
            foreach (var p in FanAndPower.Profiles)
            {
                var id = p.Id;
                menu.Items.Add(p.Name, null, (_, _) => Dispatcher.Invoke(() => SelectProfileCard(id)));
            }
            menu.Items.Add("Padrão do sistema", null, (_, _) => Dispatcher.Invoke(() => SelectProfileCard("none")));
            menu.Items.Add(new WF.ToolStripSeparator());
            menu.Items.Add("Sair", null, (_, _) => ExitApp());

            using var s = Application.GetResourceStream(new Uri("pack://application:,,,/Assets/app.ico")).Stream;
            _tray = new WF.NotifyIcon
            {
                Icon = new System.Drawing.Icon(s, 32, 32),
                Visible = true,
                Text = "TH Control",
                ContextMenuStrip = menu
            };
            _tray.DoubleClick += (_, _) => ShowFromTray();
        }

        // =====================================================================
        //  PawnIO
        // =====================================================================

        void UpdatePawnUi()
        {
            bool ok = PawnIO.Installed;
            PawnBanner.Visibility = ok ? Visibility.Collapsed : Visibility.Visible;
            TxtPawnStatus.Text = ok
                ? "Instalado. Temperaturas da CPU, placa-mãe e ventoinhas disponíveis (quando o hardware permite)."
                : "Não instalado. Sem ele a temperatura da CPU, os sensores da placa-mãe e o controle de ventoinhas não funcionam.";
            BtnPawnInstall.Visibility = ok ? Visibility.Collapsed : Visibility.Visible;
        }

        async void InstallPawn_Click(object sender, RoutedEventArgs e)
        {
            if (!Confirm("Instalar o driver PawnIO pelo winget (Microsoft)?\n\nÉ o driver usado pelo LibreHardwareMonitor para ler sensores. Depois o TH Control precisa ser reiniciado.")) return;
            ShowBusy("Instalando PawnIO...");
            bool ok = await PawnIO.InstallAsync();
            HideBusy();
            UpdatePawnUi();
            if (ok)
            {
                if (Confirm("PawnIO instalado. Reiniciar o TH Control agora para ler todos os sensores?"))
                {
                    System.Diagnostics.Process.Start(Environment.ProcessPath!);
                    ExitApp();
                }
            }
            else if (Confirm("Não foi possível instalar pelo winget. Abrir a página de download do PawnIO?"))
                Shell.Open(PawnIO.DownloadUrl);
        }

        void DownloadPawn_Click(object sender, RoutedEventArgs e) => Shell.Open(PawnIO.DownloadUrl);

        // =====================================================================
        //  Sensores
        // =====================================================================

        bool MatchSensor(SensorRow r)
        {
            string q = TxtSensorSearch.Text.Trim();
            return q.Length == 0
                   || r.Name.Contains(q, StringComparison.CurrentCultureIgnoreCase)
                   || r.Group.Contains(q, StringComparison.CurrentCultureIgnoreCase)
                   || r.TypeName.Contains(q, StringComparison.CurrentCultureIgnoreCase)
                   || r.Type.ToString().Contains(q, StringComparison.OrdinalIgnoreCase);
        }

        void SensorSearch_Changed(object sender, TextChangedEventArgs e)
        {
            PhSensorSearch.Visibility = TxtSensorSearch.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            _sensorView?.Refresh();
        }

        async void ResetMinMax_Click(object sender, RoutedEventArgs e)
        {
            await Task.Run(() => _hw.ResetMinMax());
            await TickAsync();
            Status("Mínimos e máximos zerados.");
        }

        void ExportSensors_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog
            {
                Title = "Exportar sensores",
                FileName = $"sensores_{DateTime.Now:yyyy-MM-dd_HH-mm}.csv",
                Filter = "Planilha CSV (*.csv)|*.csv|Texto (*.txt)|*.txt"
            };
            if (dlg.ShowDialog(this) != true) return;
            bool csv = dlg.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase);
            var sb = new StringBuilder();
            sb.AppendLine(csv ? "Dispositivo;Sensor;Tipo;Atual;Mínimo;Máximo" : $"TH Control — sensores em {DateTime.Now:dd/MM/yyyy HH:mm}");
            foreach (var g in _rows.GroupBy(r => r.Group))
            {
                if (!csv) sb.AppendLine().AppendLine(g.Key);
                foreach (var r in g)
                    sb.AppendLine(csv
                        ? string.Join(";", r.Group, r.Name, r.TypeName, r.Value, r.Min, r.Max)
                        : $"  {r.Name,-34} {r.Value,14}  (mín {r.Min}, máx {r.Max})");
            }
            File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
            Status("Sensores exportados: " + dlg.FileName);
        }

        // =====================================================================
        //  Ventoinhas e energia
        // =====================================================================

        void SelectProfileCard(string id)
        {
            var target = id switch { "silent" => ProfSilent, "balanced" => ProfBalanced, "performance" => ProfPerf, _ => ProfNone };
            if (target.IsChecked == true) return;
            target.IsChecked = true; // dispara Profile_Checked
        }

        async void Profile_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is not RadioButton rb || rb.Tag is not string id) return;
            string old = _s.Profile;
            _s.Profile = id;
            _s.Save();
            TxtDashProfile.Text = id == "none" ? "" : "Perfil: " + FanAndPower.Profiles.First(p => p.Id == id).Name;
            if (_loading || old == id && !IsLoaded) return;

            var p = FanAndPower.Profiles.FirstOrDefault(x => x.Id == id);
            if (p != null)
            {
                ShowBusy($"Aplicando perfil {p.Name}...");
                await FanAndPower.ApplyPowerAsync(p);
                HideBusy();
                Status($"Perfil {p.Name} aplicado.");
            }
            else
            {
                await Shell.RunAsync("powercfg.exe", "/setacvalueindex SCHEME_BALANCED SUB_PROCESSOR PROCTHROTTLEMAX 100");
                await Shell.RunAsync("powercfg.exe", "/setdcvalueindex SCHEME_BALANCED SUB_PROCESSOR PROCTHROTTLEMAX 100");
                Status("Padrão do sistema: o Windows e a BIOS voltam a controlar.");
            }
            await RefreshPlanAsync();
        }

        async Task RefreshPlanAsync()
        {
            string plan = await FanAndPower.ActivePlanNameAsync();
            TxtPlan.Text = plan.Length > 0 ? $"Plano de energia ativo no Windows: {plan}" : "";
        }

        void Channel_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (sender is not FanChannel ch || (e.PropertyName != nameof(FanChannel.Mode) && e.PropertyName != nameof(FanChannel.Manual))) return;
            _s.Fans[ch.Id] = new FanSetting { Mode = ch.Mode, Manual = ch.Manual };
            _s.Save();
        }

        // =====================================================================
        //  Internet
        // =====================================================================

        void RefreshNetworkInfo()
        {
            _adapter = NetworkTools.Info(NetworkTools.ActiveAdapter());
            if (_adapter == null)
            {
                TxtAdapter.Text = "Sem conexão com a internet";
                TxtAdapterInfo.Text = "";
                TxtDnsCurrent.Text = "";
                return;
            }
            TxtAdapter.Text = _adapter.Name;
            TxtAdapterInfo.Text = $"{_adapter.Type} · conectado a {_adapter.Speed} · IP {_adapter.Ip} · roteador {_adapter.Gateway}"
                                  + (_adapter.Type == "Wi-Fi" ? "\nDica: cabo de rede costuma dar ping menor e mais estável que Wi-Fi." : "");
            foreach (var d in _dns)
                d.IsCurrent = d.IsAuto
                    ? !_dns.Any(x => !x.IsAuto && _adapter.Dns.Contains(x.Primary))
                    : _adapter.Dns.Contains(d.Primary);
            var cur = _dns.FirstOrDefault(d => d.IsCurrent);
            string servers = _adapter.Dns.Length > 0 ? string.Join(", ", _adapter.Dns) : "—";
            TxtDnsCurrent.Text = cur == null || cur.IsAuto
                ? $"Você está usando o DNS do provedor ({servers})"
                : $"Você está usando: {cur.Name} ({servers})";
        }

        void UpdateNetworkSpeed()
        {
            try
            {
                var nic = NetworkTools.ActiveAdapter();
                if (nic == null) return;
                var st = nic.GetIPv4Statistics();
                var now = DateTime.Now;
                double secs = (now - _lastNetSample).TotalSeconds;
                if (_lastRx >= 0 && secs > 0)
                {
                    TxtDown.Text = Fmt.Speed(Math.Max(0, st.BytesReceived - _lastRx) / secs);
                    TxtUp.Text = Fmt.Speed(Math.Max(0, st.BytesSent - _lastTx) / secs);
                }
                _lastRx = st.BytesReceived;
                _lastTx = st.BytesSent;
                _lastNetSample = now;
            }
            catch { }
        }

        void PingToggle_Click(object sender, RoutedEventArgs e)
        {
            _pinging = !_pinging;
            BtnPing.Content = _pinging ? "Parar" : "Iniciar";
            if (_pinging)
            {
                _s.PingHost = TxtPingHost.Text.Trim();
                _s.Save();
                _pings.Clear();
                _pingTimer.Start();
            }
            else _pingTimer.Stop();
        }

        void PingPreset_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.Tag is not string host) return;
            if (host == "gateway") host = _adapter?.Gateway ?? "192.168.0.1";
            TxtPingHost.Text = host;
            _s.PingHost = host;
            _s.Save();
            _pings.Clear();
            if (!_pinging) PingToggle_Click(sender, e);
        }

        async Task PingAsync()
        {
            string host = _s.PingHost;
            long? ms = null;
            try
            {
                using var p = new Ping();
                var reply = await p.SendPingAsync(host, 1000);
                if (reply.Status == IPStatus.Success) ms = reply.RoundtripTime;
            }
            catch { }

            _pings.Add(ms);
            while (_pings.Count > PingSamples) _pings.RemoveAt(0);

            var ok = _pings.Where(x => x.HasValue).Select(x => (double)x!.Value).ToList();
            TxtPingNow.Text = ms.HasValue ? $"{ms} ms" : "—";
            TxtDashPing.Text = ms.HasValue ? $"Ping {ms} ms" : "Ping —";
            if (ok.Count > 0)
            {
                double avg = ok.Average();
                double jitter = ok.Count > 1 ? ok.Zip(ok.Skip(1), (a, b) => Math.Abs(b - a)).Average() : 0;
                TxtPingAvg.Text = $"{avg:0} ms";
                TxtPingMin.Text = $"{ok.Min():0} ms";
                TxtPingMax.Text = $"{ok.Max():0} ms";
                TxtPingJitter.Text = $"{jitter:0} ms";
            }
            double loss = _pings.Count > 0 ? _pings.Count(x => !x.HasValue) * 100.0 / _pings.Count : 0;
            TxtPingLoss.Text = $"{loss:0}%";
            if (ok.Count > 0)
            {
                double avg = ok.Average();
                double jitter = ok.Count > 1 ? ok.Zip(ok.Skip(1), (a, b) => Math.Abs(b - a)).Average() : 0;
                TxtPingQuality.Text = loss >= 2 ? "Perdendo pacotes: pode dar lag e teleporte"
                                    : jitter > 10 ? "Ping instável: pode engasgar"
                                    : avg < 30 ? "Excelente para jogos"
                                    : avg < 60 ? "Bom para jogos"
                                    : avg < 100 ? "Aceitável, dá para sentir em jogos rápidos"
                                    : "Alto: atraso perceptível";
            }
            else TxtPingQuality.Text = "Sem resposta do servidor";

            double max = Math.Max(50, ok.Count > 0 ? ok.Max() * 1.25 : 50);
            TxtPingScale.Text = $"{max:0} ms";
            var vals = _pings.Select(x => x.HasValue ? (float?)x.Value : null).ToList();
            double w = PingGraph.ActualWidth, h = PingGraph.ActualHeight;
            PingLine.Data = Line(vals, w, h, PingSamples, max);
            PingFill.Data = Area(vals, w, h, PingSamples, max);
        }

        static Geometry? Area(IList<float?> values, double w, double h, int capacity, double max)
        {
            if (w <= 0 || h <= 0 || values.Count < 2) return null;
            double step = w / (capacity - 1);
            double x0 = w - (values.Count - 1) * step;
            var g = new StreamGeometry();
            using (var c = g.Open())
            {
                c.BeginFigure(new Point(x0, h), true, true);
                for (int i = 0; i < values.Count; i++)
                {
                    double v = values[i] ?? 0;
                    c.LineTo(new Point(x0 + i * step, h - 4 - (h - 8) * Math.Clamp(v / max, 0, 1)), false, true);
                }
                c.LineTo(new Point(w, h), false, false);
            }
            g.Freeze();
            return g;
        }

        async void DnsTest_Click(object sender, RoutedEventArgs e)
        {
            Status("Testando servidores DNS...");
            foreach (var d in _dns.Where(d => !d.IsAuto)) d.Latency = "...";
            var auto = _dns.First(d => d.IsAuto);
            auto.Latency = "...";

            foreach (var d in _dns.Where(d => !d.IsAuto))
            {
                d.Ms = await NetworkTools.MeasureDnsAsync(d.Primary);
                d.Latency = d.Ms.HasValue ? $"{d.Ms:0} ms" : "falhou";
            }
            var isp = _adapter?.Dns.FirstOrDefault(x => !_dns.Any(d => d.Primary == x));
            if (isp != null)
            {
                auto.Ms = await NetworkTools.MeasureDnsAsync(isp);
                auto.Latency = auto.Ms.HasValue ? $"{auto.Ms:0} ms" : "falhou";
            }
            else auto.Latency = "";

            var best = _dns.Where(d => d.Ms.HasValue).OrderBy(d => d.Ms).FirstOrDefault();
            Status(best != null ? $"Mais rápido para você: {best.Name} ({best.Ms:0} ms)." : "Não foi possível testar os DNS.");
        }

        async void DnsApply_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is not DnsProvider d) return;
            if (_adapter == null || _adapter.Index < 0) { Status("Nenhuma conexão ativa."); return; }
            ShowBusy($"Trocando DNS para {d.Name}...");
            bool ok = await NetworkTools.SetDnsAsync(_adapter.Index, d);
            HideBusy();
            await Task.Delay(800);
            RefreshNetworkInfo();
            Status(ok ? $"DNS alterado para {d.Name}." : "Não foi possível alterar o DNS.");
        }

        async void DnsFlush_Click(object sender, RoutedEventArgs e)
        {
            await NetworkTools.FlushDnsAsync();
            Status("Cache DNS limpo.");
        }

        void RefreshNetTweaks()
        {
            bool was = _loading;
            _loading = true;
            ChkNagle.IsChecked = _adapter != null && NetworkTools.NagleDisabled(_adapter.Id);
            ChkThrottle.IsChecked = NetworkTools.ThrottlingOff();
            ChkQos.IsChecked = _s.QosApplied;
            _loading = was;
        }

        void Nagle_Changed(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            try { NetworkTools.SetNagle(ChkNagle.IsChecked == true); Status("Pronto. Reinicie o PC para valer."); }
            catch (Exception ex) { Status("Erro: " + ex.Message); }
        }

        void Throttle_Changed(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            try { NetworkTools.SetThrottling(ChkThrottle.IsChecked == true); Status("Pronto. Reinicie o PC para valer."); }
            catch (Exception ex) { Status("Erro: " + ex.Message); }
        }

        async void Qos_Changed(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.GameExes = TxtGames.Text;
            bool on = ChkQos.IsChecked == true;
            ShowBusy(on ? "Aplicando prioridade de rede..." : "Removendo prioridade de rede...");
            bool ok = true;
            if (on) ok = await NetworkTools.ApplyQosAsync(_s.GameExes.Split(',', ';'));
            else await NetworkTools.RemoveQosAsync();
            HideBusy();
            _s.QosApplied = on && ok;
            _s.Save();
            if (on && !ok)
            {
                _loading = true; ChkQos.IsChecked = false; _loading = false;
                Status("Não foi possível criar a regra de prioridade.");
            }
            else Status(on ? "Prioridade de rede ativada para os jogos da lista." : "Prioridade de rede removida.");
        }

        async void ResetNet_Click(object sender, RoutedEventArgs e)
        {
            if (!Confirm("Redefinir a rede do Windows (Winsock e TCP/IP)?\n\nUse quando a internet estiver com problemas. Será preciso reiniciar o PC.")) return;
            ShowBusy("Redefinindo rede...");
            await NetworkTools.ResetNetworkAsync();
            HideBusy();
            MessageBox.Show(this, "Rede redefinida. Reinicie o PC para concluir.", "TH Control", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // =====================================================================
        //  Configurações
        // =====================================================================

        void LoadSettingsUi()
        {
            bool was = _loading;
            _loading = true;
            RbDark.IsChecked = _s.Theme == "dark";
            RbBlack.IsChecked = _s.Theme == "black";
            RbLight.IsChecked = _s.Theme == "light";
            TxtColorA.Text = _s.AccentA;
            TxtColorB.Text = _s.AccentB;
            ChkLogoAccent.IsChecked = _s.LogoUseAccent;
            TxtLogoP.Text = _s.LogoPrimary;
            TxtLogoS.Text = _s.LogoSecondary;
            RbCelsius.IsChecked = !_s.Fahrenheit;
            RbFahrenheit.IsChecked = _s.Fahrenheit;
            SldRefresh.Value = Math.Clamp(_s.RefreshMs / 1000, 1, 5);
            ChkStartup.IsChecked = _s.StartWithWindows;
            ChkStartMin.IsChecked = _s.StartMinimized;
            ChkTray.IsChecked = _s.CloseToTray;
            ChkRestoreFans.IsChecked = _s.RestoreFansOnExit;
            TxtPingHost.Text = _s.PingHost;
            TxtGames.Text = _s.GameExes;
            UpdateLabels();
            RefreshColorUi();
            _loading = was;
        }

        void HookSettings()
        {
            foreach (var cb in new[] { ChkStartMin, ChkTray, ChkRestoreFans })
            {
                cb.Checked += SettingChanged;
                cb.Unchecked += SettingChanged;
            }
            SldRefresh.ValueChanged += (_, _) => SettingChanged(null, null);
            RbCelsius.Checked += SettingChanged;
            RbFahrenheit.Checked += SettingChanged;

            ChkStartup.Checked += async (_, _) => await StartupChanged(true);
            ChkStartup.Unchecked += async (_, _) => await StartupChanged(false);

            ChkNagle.Checked += Nagle_Changed; ChkNagle.Unchecked += Nagle_Changed;
            ChkThrottle.Checked += Throttle_Changed; ChkThrottle.Unchecked += Throttle_Changed;
            ChkQos.Checked += Qos_Changed; ChkQos.Unchecked += Qos_Changed;
            TxtGames.LostFocus += (_, _) => { _s.GameExes = TxtGames.Text; _s.Save(); };

            foreach (var rb in new[] { RbDark, RbBlack, RbLight }) rb.Checked += Theme_Checked;
            ChkLogoAccent.Checked += (_, _) => CommitColors();
            ChkLogoAccent.Unchecked += (_, _) => CommitColors();
            foreach (var tb in new[] { TxtColorA, TxtColorB, TxtLogoP, TxtLogoS })
            {
                tb.LostFocus += (_, _) => CommitColors();
                tb.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitColors(); };
            }
            PrevA.MouseLeftButtonUp += (_, _) => PickColor(TxtColorA);
            PrevB.MouseLeftButtonUp += (_, _) => PickColor(TxtColorB);
            PrevLogoP.MouseLeftButtonUp += (_, _) => PickColor(TxtLogoP);
            PrevLogoS.MouseLeftButtonUp += (_, _) => PickColor(TxtLogoS);
        }

        void SettingChanged(object? sender, RoutedEventArgs? e)
        {
            UpdateLabels();
            if (_loading) return;
            _s.Fahrenheit = RbFahrenheit.IsChecked == true;
            _s.RefreshMs = (int)SldRefresh.Value * 1000;
            _s.StartMinimized = ChkStartMin.IsChecked == true;
            _s.CloseToTray = ChkTray.IsChecked == true;
            _s.RestoreFansOnExit = ChkRestoreFans.IsChecked == true;
            _s.Save();
            _timer.Interval = TimeSpan.FromMilliseconds(_s.RefreshMs);
        }

        async Task StartupChanged(bool on)
        {
            if (_loading) return;
            _s.StartWithWindows = on;
            _s.Save();
            await StartupManager.SetAsync(on);
            Status(on ? "O TH Control vai iniciar com o Windows." : "Início automático desativado.");
        }

        void UpdateLabels()
        {
            int sec = (int)SldRefresh.Value;
            LblRefresh.Text = $"Atualizar a cada {sec} segundo{(sec > 1 ? "s" : "")}";
            TxtLogoP.IsEnabled = PrevLogoP.IsEnabled = ChkLogoAccent.IsChecked != true;
            TxtLogoP.Opacity = PrevLogoP.Opacity = ChkLogoAccent.IsChecked == true ? 0.4 : 1;
        }

        void Theme_Checked(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.Theme = sender == RbLight ? "light" : sender == RbBlack ? "black" : "dark";
            _s.Save();
            ThemeManager.Apply(_s);
            RefreshColorUi();
        }

        void BuildSwatches()
        {
            foreach (var p in ThemeManager.Presets)
            {
                var b = new Border
                {
                    Width = 26, Height = 26,
                    CornerRadius = new CornerRadius(13),
                    Margin = new Thickness(0, 0, 8, 8),
                    BorderThickness = new Thickness(2),
                    Cursor = Cursors.Hand,
                    ToolTip = p.Name,
                    Tag = p,
                    Background = new LinearGradientBrush(ThemeManager.Parse(p.A, p.A), ThemeManager.Parse(p.B, p.B), new Point(0, 0), new Point(1, 1))
                };
                b.MouseLeftButtonUp += (_, _) => { TxtColorA.Text = p.A; TxtColorB.Text = p.B; CommitColors(); };
                Swatches.Children.Add(b);
            }
        }

        void CommitColors()
        {
            UpdateLabels();
            if (_loading) return;
            _s.AccentA = Valid(TxtColorA, _s.AccentA);
            _s.AccentB = Valid(TxtColorB, _s.AccentB);
            _s.LogoPrimary = Valid(TxtLogoP, _s.LogoPrimary);
            _s.LogoSecondary = Valid(TxtLogoS, _s.LogoSecondary);
            _s.LogoUseAccent = ChkLogoAccent.IsChecked == true;
            _s.Save();
            ThemeManager.Apply(_s);
            RefreshColorUi();
        }

        static string Valid(TextBox tb, string fallback)
        {
            string v = ThemeManager.TryParse(tb.Text, out var n) ? n : fallback;
            tb.Text = v;
            return v;
        }

        void PickColor(TextBox target)
        {
            var c = ThemeManager.Parse(target.Text, "#FFFFFF");
            using var dlg = new WF.ColorDialog { FullOpen = true, Color = System.Drawing.Color.FromArgb(c.R, c.G, c.B) };
            if (dlg.ShowDialog() != WF.DialogResult.OK) return;
            target.Text = $"#{dlg.Color.R:X2}{dlg.Color.G:X2}{dlg.Color.B:X2}";
            CommitColors();
        }

        void RefreshColorUi()
        {
            var ring = (Brush)FindResource("TextBrush");
            foreach (Border b in Swatches.Children)
            {
                var p = ((string Name, string A, string B))b.Tag;
                bool sel = string.Equals(p.A, _s.AccentA, StringComparison.OrdinalIgnoreCase)
                        && string.Equals(p.B, _s.AccentB, StringComparison.OrdinalIgnoreCase);
                b.BorderBrush = sel ? ring : Brushes.Transparent;
            }
            PrevA.Background = Solid(_s.AccentA);
            PrevB.Background = Solid(_s.AccentB);
            PrevLogoP.Background = Solid(_s.LogoPrimary);
            PrevLogoS.Background = Solid(_s.LogoSecondary);
        }

        static SolidColorBrush Solid(string hex) => new(ThemeManager.Parse(hex, "#FFFFFF"));

        void GitHub_Click(object sender, RoutedEventArgs e) => Shell.Open("https://github.com/Thiagosystems");
    }
}

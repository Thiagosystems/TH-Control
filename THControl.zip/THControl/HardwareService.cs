using System;
using System.Collections.Generic;
using System.Linq;
using LibreHardwareMonitor.Hardware;

namespace THControl
{
    // =========================================================================
    //  Modelos para a interface
    // =========================================================================

    public class SensorRow : Observable
    {
        string _value = "", _min = "", _max = "";
        public string Id { get; init; } = "";
        public string Group { get; init; } = "";
        public string Name { get; init; } = "";
        public SensorType Type { get; init; }
        public string TypeName => HardwareService.TypeName(Type);
        public string Value { get => _value; set => Set(ref _value, value); }
        public string Min { get => _min; set => Set(ref _min, value); }
        public string Max { get => _max; set => Set(ref _max, value); }
    }

    public record DiskInfo(string Name, float? Temp, float? Health, float? WrittenGB, float? UsedPct);
    public record FanInfo(string Name, float Rpm);

    public class HwSummary
    {
        public string CpuName = "", GpuName = "";
        public float? CpuLoad, CpuTemp, CpuClock, CpuPower;
        public float? GpuLoad, GpuTemp, GpuHotspot, GpuClock, GpuPower, GpuMemUsed, GpuMemTotal, GpuFan;
        public float? RamUsed, RamAvail, RamLoad;
        public List<DiskInfo> Disks = new();
        public List<FanInfo> Fans = new();
    }

    // =========================================================================
    //  Serviço (LibreHardwareMonitorLib)
    // =========================================================================

    public sealed class HardwareService : IDisposable
    {
        readonly Computer _pc;
        readonly object _lock = new();
        public bool IsOpen { get; private set; }
        public string? Error { get; private set; }

        public HardwareService()
        {
            _pc = new Computer
            {
                IsCpuEnabled = true,
                IsGpuEnabled = true,
                IsMemoryEnabled = true,
                IsMotherboardEnabled = true,
                IsControllerEnabled = true,
                IsStorageEnabled = true,
                IsBatteryEnabled = true,
                IsPsuEnabled = true,
                IsNetworkEnabled = false
            };
        }

        public void Open()
        {
            lock (_lock)
            {
                try { _pc.Open(); IsOpen = true; }
                catch (Exception ex) { Error = ex.Message; }
            }
        }

        public void Update()
        {
            if (!IsOpen) return;
            lock (_lock)
            {
                foreach (var hw in _pc.Hardware)
                {
                    try { UpdateHw(hw); } catch { }
                }
            }
        }

        static void UpdateHw(IHardware hw)
        {
            hw.Update();
            foreach (var sub in hw.SubHardware) UpdateHw(sub);
        }

        public T Read<T>(Func<T> f) { lock (_lock) return f(); }
        public void Do(Action a) { lock (_lock) a(); }

        public void ResetMinMax()
        {
            lock (_lock)
                foreach (var (_, _, s) in All())
                {
                    try { s.ResetMin(); s.ResetMax(); } catch { }
                }
        }

        public void Dispose()
        {
            lock (_lock)
            {
                try { if (IsOpen) _pc.Close(); } catch { }
                IsOpen = false;
            }
        }

        // ------------------------------------------------------------ percurso

        /// <summary>Todos os sensores com o nome do grupo (chamar dentro de Read/Do).</summary>
        public IEnumerable<(IHardware Hw, string Group, ISensor Sensor)> All()
        {
            foreach (var hw in _pc.Hardware)
                foreach (var x in Walk(hw, $"{HwTypeName(hw.HardwareType)} · {hw.Name}"))
                    yield return x;
        }

        static IEnumerable<(IHardware, string, ISensor)> Walk(IHardware hw, string group)
        {
            foreach (var s in hw.Sensors) yield return (hw, group, s);
            foreach (var sub in hw.SubHardware)
                foreach (var x in Walk(sub, $"{group} › {sub.Name}"))
                    yield return x;
        }

        static IEnumerable<ISensor> Sensors(IHardware hw) => hw.Sensors.Concat(hw.SubHardware.SelectMany(Sensors));

        static float? Find(IHardware hw, SensorType t, params string[] names)
        {
            foreach (var n in names)
            {
                var s = Sensors(hw).FirstOrDefault(x => x.SensorType == t && x.Value.HasValue
                                                     && x.Name.Equals(n, StringComparison.OrdinalIgnoreCase));
                if (s != null) return s.Value;
            }
            return null;
        }

        static float? MaxOf(IHardware hw, SensorType t) =>
            Sensors(hw).Where(x => x.SensorType == t && x.Value.HasValue).Select(x => x.Value).Max();

        // -------------------------------------------------------------- resumo

        public HwSummary Summary()
        {
            var r = new HwSummary();
            lock (_lock)
            {
                if (!IsOpen) return r;
                var list = _pc.Hardware.ToList();

                var cpu = list.FirstOrDefault(h => h.HardwareType == HardwareType.Cpu);
                if (cpu != null)
                {
                    r.CpuName = cpu.Name;
                    r.CpuLoad = Find(cpu, SensorType.Load, "CPU Total");
                    r.CpuTemp = Find(cpu, SensorType.Temperature, "Core (Tctl/Tdie)", "CPU Package", "Core Average", "Tctl", "Package", "Core Max")
                                ?? MaxOf(cpu, SensorType.Temperature);
                    r.CpuClock = Find(cpu, SensorType.Clock, "Cores (Average)", "Core (Average)")
                                 ?? Sensors(cpu).Where(s => s.SensorType == SensorType.Clock && s.Name.StartsWith("Core #") && s.Value > 0)
                                                .Select(s => s.Value).Average();
                    r.CpuPower = Find(cpu, SensorType.Power, "Package", "CPU Package", "CPU Cores");
                }

                var gpu = list.FirstOrDefault(h => h.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd)
                          ?? list.FirstOrDefault(h => h.HardwareType == HardwareType.GpuIntel);
                if (gpu != null)
                {
                    r.GpuName = gpu.Name;
                    r.GpuLoad = Find(gpu, SensorType.Load, "GPU Core", "D3D 3D");
                    r.GpuTemp = Find(gpu, SensorType.Temperature, "GPU Core", "GPU Temperature") ?? MaxOf(gpu, SensorType.Temperature);
                    r.GpuHotspot = Find(gpu, SensorType.Temperature, "GPU Hot Spot");
                    r.GpuClock = Find(gpu, SensorType.Clock, "GPU Core");
                    r.GpuPower = Find(gpu, SensorType.Power, "GPU Package", "GPU Power", "GPU Core");
                    r.GpuMemUsed = Find(gpu, SensorType.SmallData, "GPU Memory Used", "D3D Dedicated Memory Used", "D3D Shared Memory Used");
                    r.GpuMemTotal = Find(gpu, SensorType.SmallData, "GPU Memory Total", "D3D Dedicated Memory Total");
                    r.GpuFan = MaxOf(gpu, SensorType.Fan);
                }

                var mem = list.FirstOrDefault(h => h.HardwareType == HardwareType.Memory && !h.Name.Contains("Virtual", StringComparison.OrdinalIgnoreCase))
                          ?? list.FirstOrDefault(h => h.HardwareType == HardwareType.Memory);
                if (mem != null)
                {
                    r.RamUsed = Find(mem, SensorType.Data, "Memory Used");
                    r.RamAvail = Find(mem, SensorType.Data, "Memory Available");
                    r.RamLoad = Find(mem, SensorType.Load, "Memory");
                }

                foreach (var d in list.Where(h => h.HardwareType == HardwareType.Storage))
                {
                    float? health = Find(d, SensorType.Level, "Remaining Life");
                    if (health == null && Find(d, SensorType.Level, "Percentage Used") is float used) health = Math.Max(0, 100 - used);
                    r.Disks.Add(new DiskInfo(
                        d.Name,
                        Sensors(d).FirstOrDefault(s => s.SensorType == SensorType.Temperature && s.Value.HasValue)?.Value,
                        health,
                        Find(d, SensorType.Data, "Data Written", "Total Bytes Written", "Host Writes"),
                        Find(d, SensorType.Load, "Used Space")));
                }

                foreach (var hw in list)
                    foreach (var (h, _, s) in Walk(hw, ""))
                        if (s.SensorType == SensorType.Fan && s.Value is float rpm)
                            r.Fans.Add(new FanInfo($"{s.Name} ({ShortName(h)})", rpm));
            }
            return r;
        }

        static string ShortName(IHardware h) => h.HardwareType switch
        {
            HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel => "GPU",
            HardwareType.SuperIO or HardwareType.Motherboard => "placa-mãe",
            HardwareType.Cooler => "cooler",
            HardwareType.EmbeddedController => "EC",
            _ => h.Name
        };

        // --------------------------------------------------------------- textos

        public static string HwTypeName(HardwareType t) => t switch
        {
            HardwareType.Cpu => "CPU",
            HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel => "GPU",
            HardwareType.Memory => "Memória",
            HardwareType.Motherboard => "Placa-mãe",
            HardwareType.SuperIO => "Sensores da placa",
            HardwareType.Storage => "Disco",
            HardwareType.Cooler => "Cooler",
            HardwareType.EmbeddedController => "Controlador",
            HardwareType.Battery => "Bateria",
            HardwareType.Psu => "Fonte",
            HardwareType.Network => "Rede",
            _ => t.ToString()
        };

        public static string TypeName(SensorType t) => t switch
        {
            SensorType.Temperature => "Temperatura",
            SensorType.Fan => "Ventoinha",
            SensorType.Load => "Uso",
            SensorType.Clock => "Clock",
            SensorType.Power => "Potência",
            SensorType.Voltage => "Tensão",
            SensorType.Current => "Corrente",
            SensorType.Control => "Controle",
            SensorType.Level => "Nível",
            SensorType.Data or SensorType.SmallData => "Dados",
            SensorType.Throughput => "Taxa",
            SensorType.Frequency => "Frequência",
            SensorType.Flow => "Fluxo",
            SensorType.Factor => "Fator",
            SensorType.Energy => "Energia",
            _ => t.ToString()
        };

        public static string Format(SensorType t, float? v, bool fahrenheit)
        {
            if (v is not float x || float.IsNaN(x)) return "—";
            return t switch
            {
                SensorType.Temperature => fahrenheit ? $"{x * 9 / 5 + 32:0} °F" : $"{x:0.0} °C",
                SensorType.Fan => $"{x:0} RPM",
                SensorType.Load or SensorType.Control or SensorType.Level => $"{x:0.0} %",
                SensorType.Clock => $"{x:0} MHz",
                SensorType.Power => $"{x:0.0} W",
                SensorType.Voltage => $"{x:0.000} V",
                SensorType.Current => $"{x:0.00} A",
                SensorType.Data => $"{x:0.0} GB",
                SensorType.SmallData => $"{x:0} MB",
                SensorType.Throughput => Fmt.Bytes(x) + "/s",
                SensorType.Frequency => $"{x:0} Hz",
                SensorType.Flow => $"{x:0} L/h",
                SensorType.Energy => $"{x:0} mWh",
                _ => $"{x:0.##}"
            };
        }

        public static string Temp(float? v, bool fahrenheit) =>
            v is float x ? (fahrenheit ? $"{x * 9 / 5 + 32:0}°F" : $"{x:0}°C") : "—";
    }
}

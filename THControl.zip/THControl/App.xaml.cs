using System.Linq;
using System.Threading;
using System.Windows;

namespace THControl
{
    public partial class App : Application
    {
        Mutex? _mutex;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            _mutex = new Mutex(true, "THControl_SingleInstance", out bool created);
            if (!created) { Shutdown(); return; }

            var settings = Settings.Load();
            ThemeManager.Apply(settings);

            bool hidden = e.Args.Contains("--tray") && settings.StartMinimized;
            var window = new MainWindow(settings, hidden);
            MainWindow = window;
            window.Show(); // StartAsync esconde a janela se iniciar na bandeja
        }
    }
}

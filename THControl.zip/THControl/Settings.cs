using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace THControl
{
    public class FanSetting
    {
        public int Mode { get; set; } = 0;     // 0 = segue o perfil, 1 = manual, 2 = automático (BIOS)
        public int Manual { get; set; } = 50;  // %
    }

    public class Settings
    {
        // Aparência
        public string Theme { get; set; } = "dark";
        public string AccentA { get; set; } = "#22D3EE";
        public string AccentB { get; set; } = "#8B5CF6";
        public bool LogoUseAccent { get; set; } = false;
        public string LogoPrimary { get; set; } = "#E10600";
        public string LogoSecondary { get; set; } = "#E6E6E6";

        // Monitor
        public bool Fahrenheit { get; set; } = false;
        public int RefreshMs { get; set; } = 1000;

        // Ventoinhas e energia
        public string Profile { get; set; } = "none";   // none | silent | balanced | performance
        public Dictionary<string, FanSetting> Fans { get; set; } = new();
        public bool RestoreFansOnExit { get; set; } = true;

        // Internet
        public string PingHost { get; set; } = "1.1.1.1";
        public string GameExes { get; set; } = "cs2, VALORANT-Win64-Shipping, FortniteClient-Win64-Shipping, League of Legends";
        public bool QosApplied { get; set; } = false;

        // Sistema
        public bool CloseToTray { get; set; } = true;
        public bool StartWithWindows { get; set; } = false;
        public bool StartMinimized { get; set; } = true;
        public bool TrayHintShown { get; set; } = false;

        public static string DataDir => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "THControl");
        static string FilePath => Path.Combine(DataDir, "settings.json");

        public static Settings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var s = JsonSerializer.Deserialize<Settings>(File.ReadAllText(FilePath)) ?? new Settings();
                    s.Fans ??= new();
                    return s;
                }
            }
            catch { }
            return new Settings();
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(DataDir);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { }
        }
    }
}
